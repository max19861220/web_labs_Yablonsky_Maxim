require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static('public'));

// Підключення до MongoDB
mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('✅ MongoDB connected'))
    .catch(err => console.log('❌ MongoDB connection error:', err));

// Схема продукту
const productSchema = new mongoose.Schema({
    name: { type: String, required: true },
    category: { type: String, required: true },
    price: { type: Number, required: true }
}, { timestamps: true });

const Product = mongoose.model('Product', productSchema);

// Маршрути
app.get('/product/list', async (req, res) => {
    try {
        const products = await Product.find();
        res.json(products);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/product/create', async (req, res) => {
    try {
        const { name, category, price } = req.body;
        if (!name || !category || price === undefined) {
            return res.status(400).json({ error: 'Всі поля обов\'язкові' });
        }
        const product = new Product({ name, category, price });
        await product.save();
        res.status(201).json(product);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put('/product/:id', async (req, res) => {
    try {
        const { price } = req.body;
        if (price === undefined) {
            return res.status(400).json({ error: 'Вкажіть нову ціну' });
        }
        const product = await Product.findByIdAndUpdate(
            req.params.id,
            { price },
            { new: true, runValidators: true }
        );
        if (!product) {
            return res.status(404).json({ error: 'Продукт не знайдено' });
        }
        res.json(product);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/product/:id', async (req, res) => {
    try {
        const product = await Product.findByIdAndDelete(req.params.id);
        if (!product) {
            return res.status(404).json({ error: 'Продукт не знайдено' });
        }
        res.json({ message: 'Продукт видалено', product });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/', (req, res) => {
    res.send('Hello, Express!');
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
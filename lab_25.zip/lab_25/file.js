const fs = require('fs');

fs.readFile('info.txt', 'utf8', (err, data) => {
    if (err) {
        console.error('Помилка читання:', err);
        return;
    }
    console.log('Вміст info.txt:');
    console.log(data);
});

const args = process.argv.slice(2);
if (args.length > 0) {
    const text = args.join(' ');
    fs.writeFile('output.txt', text, (err) => {
        if (err) {
            console.error('Помилка запису:', err);
            return;
        }
        console.log('Текст записано у файл output.txt');
    });
} else {
    console.log('Щоб записати текст, викличте: node file.js "ваш текст"');
}